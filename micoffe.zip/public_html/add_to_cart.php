<?php
require_once 'email.php';
include 'config.php'

?>