<?php
$conn = mysqli_connect('localhost','root','','shop_db') or die('connection failed');


define('SENDGRID_API_KEY','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');
?>